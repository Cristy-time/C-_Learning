﻿using System;
using System.Threading;
namespace First_Homework
{
    public class CodeFile1
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("你好！我是张皓源");
            Thread.Sleep(1000);
        }
    }
}